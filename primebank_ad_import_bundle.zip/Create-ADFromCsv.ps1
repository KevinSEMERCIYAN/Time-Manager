<#  Create-ADFromCsv.ps1  (primebank.local)
    - OU.csv, Groups.csv, Users.csv
    - Accepte OU en DN (OU=...,DC=primebank,DC=local) OU en chemin (Utilisateurs/Conseillers)
    - Vérifie/force le suffixe DC=primebank,DC=local

    Exécution :
      .\Create-ADFromCsv.ps1 -CsvRoot "C:\Temp\CSV" -WhatIf
      .\Create-ADFromCsv.ps1 -CsvRoot "C:\Temp\CSV"
#>

[CmdletBinding(SupportsShouldProcess=$true)]
param(
  [Parameter(Mandatory=$false)]
  [string]$CsvRoot = ".",

  [Parameter(Mandatory=$false)]
  [SecureString]$DefaultPassword,

  # Par défaut on ignore les conteneurs "CN=Users" / "CN=Builtin"
  [switch]$IncludeBuiltins
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

Import-Module ActiveDirectory -ErrorAction Stop

# --- Domaine cible ---
$DomainFqdn = "primebank.local"
$DomainDN   = "DC=primebank,DC=local"

# --- Fichiers ---
$OUCsv     = Join-Path $CsvRoot "OU.csv"
$GroupsCsv = Join-Path $CsvRoot "Groups.csv"
$UsersCsv  = Join-Path $CsvRoot "Users.csv"
foreach ($f in @($OUCsv,$GroupsCsv,$UsersCsv)) {
  if (-not (Test-Path $f)) { throw "Fichier introuvable: $f" }
}

function Is-BuiltinContainer {
  param([Parameter(Mandatory)][string]$DnOrPath)
  return ($DnOrPath -match "(?i)^CN=Users," -or $DnOrPath -match "(?i)^CN=Builtin,")
}

function Normalize-OuPathToDn {
  param(
    [Parameter(Mandatory)][string]$OuValue,
    [Parameter(Mandatory)][string]$DomainDN
  )
  $v = $OuValue.Trim()

  # Si déjà un DN complet
  if ($v -match "(?i)\bDC=") {
    # Si pas bon suffixe -> erreur (évite d’écrire dans un autre domaine)
    if ($v -notmatch [regex]::Escape($DomainDN) + "$") {
      throw "OU/Path ne correspond pas au domaine $DomainDN : '$v'"
    }
    return $v
  }

  # Sinon, accepter un chemin style "Utilisateurs/Conseillers" ou "Utilisateurs\Conseillers"
  $parts = $v -split "[/\\]" | Where-Object { $_ -and $_.Trim() -ne "" }

  if ($parts.Count -eq 0) { throw "OU vide/invalide: '$OuValue'" }

  # DN = OU=Enfant,OU=Parent,DC=...
  $ouDn = (($parts | ForEach-Object { "OU=$($_.Trim())" }) -join ",")
  return "$ouDn,$DomainDN"
}

function Get-ParentDn {
  param([Parameter(Mandatory)][string]$DistinguishedName)
  $parts = $DistinguishedName -split ","
  if ($parts.Count -lt 2) { return $null }
  return ($parts[1..($parts.Count-1)] -join ",")
}

function Get-DnDepth {
  param([Parameter(Mandatory)][string]$DistinguishedName)
  return ([regex]::Matches($DistinguishedName, "(?i)\bOU=")).Count
}

function Ensure-OU {
  param(
    [Parameter(Mandatory)][string]$Name,
    [Parameter(Mandatory)][string]$DistinguishedName,
    [string]$Description,
    [bool]$ProtectedFromAccidentalDeletion = $false
  )

  if (-not $IncludeBuiltins -and (Is-BuiltinContainer -DnOrPath $DistinguishedName)) {
    Write-Verbose "OU built-in ignorée: $DistinguishedName"
    return
  }

  $existing = Get-ADOrganizationalUnit -LDAPFilter "(distinguishedName=$DistinguishedName)" -ErrorAction SilentlyContinue
  if ($existing) { Write-Host "[OU] Existe déjà : $DistinguishedName"; return }

  $parent = Get-ParentDn -DistinguishedName $DistinguishedName
  if (-not $parent) { throw "Impossible de déterminer le parent pour: $DistinguishedName" }

  if ($PSCmdlet.ShouldProcess($DistinguishedName, "Créer l'OU")) {
    New-ADOrganizationalUnit -Name $Name -Path $parent -ProtectedFromAccidentalDeletion:$ProtectedFromAccidentalDeletion | Out-Null
    if ($Description) { Set-ADOrganizationalUnit -Identity $DistinguishedName -Description $Description | Out-Null }
    Write-Host "[OU] Créée      : $DistinguishedName"
  }
}

function Ensure-Group {
  param(
    [Parameter(Mandatory)][string]$Name,
    [Parameter(Mandatory)][string]$SamAccountName,
    [Parameter(Mandatory)][ValidateSet("Security","Distribution")] [string]$GroupCategory,
    [Parameter(Mandatory)][ValidateSet("DomainLocal","Global","Universal")] [string]$GroupScope,
    [Parameter(Mandatory)][string]$PathDn,
    [string]$Description
  )

  if (-not $IncludeBuiltins -and (Is-BuiltinContainer -DnOrPath $PathDn)) {
    Write-Verbose "Groupe built-in ignoré: $Name ($PathDn)"
    return
  }

  $existing = Get-ADGroup -Filter "SamAccountName -eq '$SamAccountName'" -ErrorAction SilentlyContinue
  if ($existing) { Write-Host "[GRP] Existe déjà: $SamAccountName"; return }

  if ($PSCmdlet.ShouldProcess($SamAccountName, "Créer le groupe")) {
    New-ADGroup -Name $Name -SamAccountName $SamAccountName -GroupCategory $GroupCategory -GroupScope $GroupScope -Path $PathDn -Description $Description | Out-Null
    Write-Host "[GRP] Créé      : $SamAccountName"
  }
}

function Ensure-User {
  param(
    [Parameter(Mandatory)][string]$SamAccountName,
    [string]$UserPrincipalName,
    [string]$GivenName,
    [string]$Surname,
    [string]$DisplayName,
    [string]$Mail,
    [Parameter(Mandatory)][string]$PathDn,
    [bool]$Enabled = $true,
    [bool]$PasswordNeverExpires = $false,
    [SecureString]$AccountPassword
  )

  if (-not $IncludeBuiltins -and (Is-BuiltinContainer -DnOrPath $PathDn)) {
    Write-Verbose "Utilisateur built-in ignoré: $SamAccountName ($PathDn)"
    return
  }

  $existing = Get-ADUser -Filter "SamAccountName -eq '$SamAccountName'" -ErrorAction SilentlyContinue
  if ($existing) { Write-Host "[USR] Existe déjà: $SamAccountName"; return }

  $name = $DisplayName
  if ([string]::IsNullOrWhiteSpace($name)) {
    $name = (@($GivenName,$Surname) -join " ").Trim()
  }
  if ([string]::IsNullOrWhiteSpace($name)) { $name = $SamAccountName }

  if (-not $AccountPassword) { throw "Mot de passe initial manquant pour $SamAccountName" }

  if ($PSCmdlet.ShouldProcess($SamAccountName, "Créer l'utilisateur")) {
    $params = @{
      Name                  = $name
      SamAccountName        = $SamAccountName
      Path                  = $PathDn
      AccountPassword       = $AccountPassword
      Enabled               = [bool]$Enabled
      ChangePasswordAtLogon = $true
      PasswordNeverExpires  = [bool]$PasswordNeverExpires
    }
    if ($UserPrincipalName) { $params.UserPrincipalName = $UserPrincipalName } else { $params.UserPrincipalName = "$SamAccountName@$DomainFqdn" }
    if ($GivenName)         { $params.GivenName = $GivenName }
    if ($Surname)           { $params.Surname   = $Surname }
    if ($DisplayName)       { $params.DisplayName = $DisplayName }
    if ($Mail)              { $params.EmailAddress = $Mail }

    New-ADUser @params | Out-Null
    Write-Host "[USR] Créé      : $SamAccountName"
  }
}

# --- Mot de passe initial ---
if (-not $DefaultPassword) {
  $DefaultPassword = Read-Host "Mot de passe initial pour les utilisateurs créés (primebank.local)" -AsSecureString
}

# --- Lecture CSV ---
$ous    = Import-Csv -Path $OUCsv
$groups = Import-Csv -Path $GroupsCsv
$users  = Import-Csv -Path $UsersCsv

# --- OU ---
Write-Host "=== Création des OU (primebank.local) ==="
$ouToCreate = $ous |
  Where-Object { $_.DistinguishedName -and $_.Name } |
  ForEach-Object {
    $_.DistinguishedName = Normalize-OuPathToDn -OuValue $_.DistinguishedName -DomainDN $DomainDN
    $_
  } |
  Sort-Object @{Expression={ Get-DnDepth -DistinguishedName $_.DistinguishedName }; Ascending=$true }

foreach ($ou in $ouToCreate) {
  $prot = $false
  if ($ou.ProtectedFromAccidentalDeletion -ne $null -and $ou.ProtectedFromAccidentalDeletion -ne "") {
    $prot = [System.Convert]::ToBoolean($ou.ProtectedFromAccidentalDeletion)
  }
  Ensure-OU -Name $ou.Name -DistinguishedName $ou.DistinguishedName -Description $ou.Description -ProtectedFromAccidentalDeletion:$prot
}

# --- Groupes ---
Write-Host "`n=== Création des Groupes (primebank.local) ==="
foreach ($g in ($groups | Where-Object { $_.SamAccountName -and $_.Name -and $_.OU })) {
  $pathDn = Normalize-OuPathToDn -OuValue $g.OU -DomainDN $DomainDN
  Ensure-Group -Name $g.Name -SamAccountName $g.SamAccountName -GroupCategory $g.GroupCategory -GroupScope $g.GroupScope -PathDn $pathDn -Description $g.Description
}

# --- Utilisateurs ---
Write-Host "`n=== Création des Utilisateurs (primebank.local) ==="
foreach ($u in ($users | Where-Object { $_.SamAccountName -and $_.OU })) {
  $pathDn  = Normalize-OuPathToDn -OuValue $u.OU -DomainDN $DomainDN

  $enabled = $true
  if ($u.Enabled -ne $null -and $u.Enabled -ne "") { $enabled = [System.Convert]::ToBoolean($u.Enabled) }

  $pne = $false
  if ($u.PasswordNeverExpires -ne $null -and $u.PasswordNeverExpires -ne "") { $pne = [System.Convert]::ToBoolean($u.PasswordNeverExpires) }

  Ensure-User `
    -SamAccountName $u.SamAccountName `
    -UserPrincipalName $u.UserPrincipalName `
    -GivenName $u.GivenName `
    -Surname $u.Surname `
    -DisplayName $u.DisplayName `
    -Mail $u.Mail `
    -PathDn $pathDn `
    -Enabled:$enabled `
    -PasswordNeverExpires:$pne `
    -AccountPassword $DefaultPassword
}

Write-Host "`nTerminé (primebank.local)."
